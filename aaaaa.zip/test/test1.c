#include "../pico_plane.c"
#include "test_constants.h"

export int main(void) {
	reset_module();
    init(&T1);
    led_set_color(0xff00000);
    while(1){
        in(&this);
        led_set_color(0xffffff);
        loop();
        sleep(100);
    }
}
# Centralized application


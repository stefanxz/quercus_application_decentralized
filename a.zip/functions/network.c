#pragma once
#include "network.h"
#include "algorithm.h"
#include "rfid.h"

#define TIMEOUT 50

int send_request_movement(int module_id, char* tub_data) {
    char data[13];
    // printf("the id is: %d\n", get_own_id());
    data[SENDER] = get_own_id();
    data[MESSAGE_TYPE] = REQUEST_MOVEMENT;
    for (int i = 0; i < 10; i++) { data[i+2] = tub_data[i]; }
    // printf("net-12 // im sending it\n");
    printf("I am sending data with sender: %d\n", data[SENDER]);
    return send_packet(module_id, data, sizeof(data));
}

int send_updated_tub_location(int tub_id, int location_belt) {
    char data[4];
    data[SENDER] = get_own_id();
    data[MESSAGE_TYPE] = TUB_LOGGING;
    data[2] = tub_id;
    data[3] = location_belt; // LASER_LEFT = 0, LASER_RIGHT = 1, RFID = 2
    return send_packet(0, data, sizeof(data));
}

int send_plane_status(int plane_id, bool arrival_status) {
    char data[4];
    data[SENDER] = get_own_id();
    data[MESSAGE_TYPE] = PLANE_STATUS;
    data[2] = plane_id;
    data[3] = arrival_status;
    return send_packet(0, data, sizeof(data));
}

int send_tub_status(char* tub_data) {
    char data[13];
    data[SENDER] = get_own_id();
    data[MESSAGE_TYPE] = TUB_STATUS;
    for (int i = 0; i < 10; i++) { data[i+2] = tub_data[i]; }
    return send_packet(0, data, sizeof(data));
}

int send_request_response(int module_id, int value) {
    char data[3];
    data[SENDER] = get_own_id();
    data[MESSAGE_TYPE] = REQUEST_RESPONSE;
    data[2] = value;
    return send_packet(module_id, data, sizeof(data));
}

char* encode_request(Request* request) {
    char data[END_OF_ENUM];
    data[PLANE_DROPOFF] = request->plane_or_drop_off;
    data[PLANE_ID] = request->plane_id;
    data[PAYLOAD] = request->payload;
    data[DEPARTURE_TIME] = request->departure_time;
    data[TUB_ID] = request->tub_id;
    data[SECURITY] = request->security_status;
    data[PLANE_ARRIVED] = request->plane_arrived;
    data[DESTINATION] = request->destination;
    return &data;
}

void decode_request(Request* request, char* data) {
    request->sender_id = data[SENDER];
    request->plane_or_drop_off = data[PLANE_DROPOFF+2];
    request->plane_id = data[PLANE_ID+2];
    request->payload = data[PAYLOAD+2];
    request->departure_time = data[DEPARTURE_TIME+2];
    request->tub_id = data[TUB_ID+2];
    request->security_status = data[SECURITY+2];
    request->plane_arrived = data[PLANE_ARRIVED+2];
    request->destination = data[DESTINATION+2];
}

int handle_request_response(char* msg) {
    return  msg[2];
}

int handle_plane_status(char* msg) {
    //TODO: Handle message
}

int handle_paths_config(char* msg) {
    //TODO: Handle message
}

int handle_tub_config(char* msg) {
    // return set_tub_id(msg[2]);
    return 0;
}

int await_message(char** msg_ptr, int expected_type) {
    int response = -1;
    char type;
    EventType e = next_event();
    while (e == EVENT_MESSAGE_RECEIVED) {
        next_message_address(msg_ptr);
        type = (*msg_ptr)[MESSAGE_TYPE];
        printf("Type: %d, Sender:%d\n", type, (*msg_ptr)[SENDER]);
        
        if(type == REQUEST_MOVEMENT) {
            response = 1;
        } 
        else if (type == REQUEST_RESPONSE) {
            response = handle_request_response(*msg_ptr);
        } else if (type == PLANE_STATUS) {
            response = handle_plane_status(*msg_ptr);
        } else if (type == PATHS_CONFIG) {
            response = handle_paths_config(*msg_ptr);
        } else if (type == TUB_CONFIG) {
            response = handle_tub_config(*msg_ptr);
        }
        if (expected_type == type) {
            // printf("net-113 // expected response got, return\n");
            return response;
        }
        e = next_event(); 
    }
    printf("Grindset\n");
    // This return is never handled, but it is here to prevent a warning
    return response;
}

bool get_response() {
    char* msg;
    printf("I am waiting for a response.\n");
    int response = await_message(&msg, REQUEST_RESPONSE);
    if(response > 0) free(msg);
    return (response == NON ? false : true);
}

bool get_request(Request* request) {
    char* msg;

    // msg[0] = (char)-7;
    // msg[1] = (char)-77;
    
    int response = await_message(&msg, REQUEST_MOVEMENT);
    printf("msg has: %d, %d, %d\n", (int)msg[SENDER], (int)msg[MESSAGE_TYPE], (int)msg[2]);
    decode_request(request, msg);
    // msg[0] = (char)0;
    // msg[1] = (char)0;
    sleep(1000);
    free(msg);
    return (response == NON ? false : true);
}
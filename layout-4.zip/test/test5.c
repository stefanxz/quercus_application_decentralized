#include "../pico_routing.c"
#include "test_constants.h"
#include "../examples.c"

export int main(void) {
    init();

    while(1){
        in();
        loop();
        sleep(100);
    }
}
